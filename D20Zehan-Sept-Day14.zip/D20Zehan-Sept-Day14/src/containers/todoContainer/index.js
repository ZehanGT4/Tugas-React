import React ,{useState} from 'react';
import Todo from '../../components/todoList';
import AddTodo from '../../components/addTodo';
import Notification from '../../components/notification';
import { Link } from 'react-router-dom';


const todoList=[
    {id:1,title: 'Mengerjakan Exercise',done:true},
    {id:2,title: 'Mengerjakan Assigment',done:false},
    {id:3,title: 'Mengerjakan Project',done:false},
]
const TodoContainer = () => {
    const [todos,setTodos]=useState(todoList)
  const handleAddTodo=(newTodo)=>{
      const newTodoList=[...todos,newTodo]
      setTodos(newTodoList)
  }
  const handleRemoveTodo=(id)=>{
      const newTodoList=todos.filter(todo=>todo.id!==id)
      setTodos(newTodoList)
  }
  const hanldeCheckboxChange=(id)=>{
      const newTodoList=todos.map(todo=>{
          if(todo.id===id)
            return {...todo,done:!todo.done}
        return todo;
        })
        setTodos(newTodoList)
  }
    return (<>
        <div className="App">
        <div className="topnav">
            <Link to="/"><p className="active" >Home</p></Link>
            <Link to="/about"><p>About</p></Link>
     </div>
        <div>
         <h1 align="center" className="">Todo List</h1>
        </div>
        
      </div>
    
    <div style={{ margin: 20 }}>
        
        <Notification/>
        {todos.length>0?todos.map((todo)=><Todo todo={todo} key={todo.id} removeTodo={handleRemoveTodo}
         handleChange={hanldeCheckboxChange}/>)
        :<p align="center">Tambahkan Todo </p>}
       <AddTodo addTodo={handleAddTodo}/>
    </div>
    </>)
}

export default TodoContainer;