import React from 'react';
import './About.css';
function About() {
  return (
    <div className="zehan">
            <div class="about-section">
        <h1>About Us Page</h1>
        <h2>Zehan Baihaqi Adalah Seorang Mahasiswa KElistrikan PLN</h2>
        <p>Berhasil</p>
        </div>
    </div>
  );
}

export default About;
