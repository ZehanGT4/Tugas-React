import React from 'react';
import { Fragment } from 'react';
import {
  BrowserRouter ,
  Switch,
  Route,
  //Link
} from "react-router-dom";
import './App.css';
import TodoContainer from './containers/todoContainer';
import About from './About.js';
import NotFound from './notFound';


function App() {
  return (
    <BrowserRouter>
      <Fragment> 
        <Switch>
          <Route path="/" exact ><TodoContainer/></Route>
          <Route path="/about">
            <About/>
          </Route>
          <Route component={NotFound}/>
        </Switch>
      
      </Fragment>
    </BrowserRouter>
   
  );
}

export default App;
