import React from 'react';
import './About.css';
function NotFound() {
  return (
    <div className="zehan">
            <div class="about-section">
        <h1>Not FOund 404</h1>
        <h2>Halam Adanda Tidak DI temukan</h2>
        </div>
    </div>
  );
}

export default NotFound;
